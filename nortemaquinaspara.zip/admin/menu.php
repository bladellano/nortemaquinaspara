<table width="1030" height="33" border="0" cellpadding="0" cellspacing="1">
  <tr>
    <td width="144" height="25" align="center" valign="middle" background="img/bk_b.png" style="background-repeat:no-repeat; background-position:center;"><a href='index_.php'><img src="img/bt_home.png" width="26" height="25" border="0" align="absmiddle" />Home</a></td>
    <td width="148" height="25" align="center" valign="middle" background="img/bk_b.png" style="background-repeat:no-repeat; background-position:center;"><a href='?link=15'><img src="img/bt_edit.png" width="25" height="25" border="0" align="absmiddle" />P&aacute;ginas</a></td>
    <td width="142" align="center" valign="middle" background="img/bk_b.png" style="background-repeat:no-repeat; background-position:center;"><a href ="?link=2"><img src="img/bt_not.png" width="26" height="25" border="0" align="absmiddle" />Not&iacute;cias/Videos</a></td>
    <td width="148" align="center" valign="middle" background="img/bk_b.png" style="background-repeat:no-repeat; background-position:center;"><a href ="?link=5"><img src="img/bt_impor.png" width="25" height="25" border="0" align="absmiddle" />Destaques</a></td>
    <td width="150" align="center" valign="middle" background="img/bk_b.png" style="background-repeat:no-repeat; background-position:center;"><a href ="?link=9"><img src="img/bt_news.png" width="28" height="25" border="0" align="absmiddle" />Newsletter</a></td>
    <td width="143" align="center" valign="middle" background="img/bk_b.png" style="background-repeat:no-repeat; background-position:center;"><a  href='?link=21' ><img src="img/bt_album.png" width="32" height="25" border="0" align="absmiddle" />Produtos</a></td>
    <td width="147" align="center" valign="middle" background="img/bk_b.png" style="background-repeat:no-repeat; background-position:center;"><a href ="sair.php"><img src="img/bt_exit.png" width="24" height="25" border="0" align="absmiddle" />Sair</a></td>
  </tr>
</table>
