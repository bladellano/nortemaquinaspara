<script type="text/javascript" src="js/jcarousellite_1.0.1.pack.js"></script>
<script type="text/javascript" src="js/carrossel.js"></script>
<link href="css/estilo.css" rel="stylesheet" type="text/css" />
<div id="carrossel">
	<ul> 
		
		<li><img src='img/logo_leut.jpg' width="" border='0'></li>
		<li><img src='img/logo_freud.jpg' border='0'></li>
		<li><img src='img/logo_fepam.png' width="150" border='0'></li>
		<li><img src='img/logo_minelli.png' border='0'></li>
		<li><img src='img/logo_indfema.png'  border='0'></li>
		<li><img src='img/logo_starret.png' width="150" border='0'></li>
		<li><img src='img/logo_vima.png' border='0'></li>
		<li><img src='img/logo_possa.png'  border='0'></li>
		<li><img src='img/logo_inabra.png'  border='0'></li>
		<li><img src='img/logo_aguia.png'  border='0'></li>
		<li><img src='img/logo_marond.png'  border='0'></li>
		<li><img src='img/logo_osg.png'  border='0'></li>
		<li><img src='img/logo_union.png'  border='0'></li>
		<li><img src='img/logo_hansatecnica.png'  border='0'></li>
		<li><img src='img/logo_tito.png'  border='0'></li>
		<li><img src='img/logo_alwema.png'  border='0'></li>
		<li><img src='img/logo_lmpe.png'  border='0'></li>
		<li><img src='img/logo_cavemac.png'  border='0'></li>
		<li><img src='img/logo_ip.png'  border='0'></li>
		<li><img src='img/logo_weinig2.png'  border='0'></li>
		<li><img src='img/logo_roster.png'  border='0'></li>
		<li><img src='img/logo_euron.png'  border='0'></li>
		<li><img src='img/logo_power.png'  border='0'></li>
		<li><img src='img/logo_metalcava.png'  border='0'></li>
		<li><img src='img/logo_mendes.png'  border='0'></li>
		<li><img src='img/logo_rullitec.png'  border='0'></li>
		<li><img src='img/logo_pinacle.png'  border='0'></li>
		<li><img src='img/logo_harwar.png'  border='0'></li>
		<li><img src='img/logo_arflux.png'  border='0'></li>
		<li><img src='img/logo_lidear.png'  border='0'></li>
		<li><img src='img/logo_arpi.png'  border='0'></li>
		<li><img src='img/logo_inmes.png'  border='0'></li>
		<li><img src='img/logo_momil.png'  border='0'></li>
		<li><img src='img/logo_relman.jpg'  border='0'></li>
		<li><img src='img/logo_mazutti.png'  border='0'></li>
		<li><img src='img/logo_dambroz.png'  border='0'></li>

	</ul>
</div>