<table width="954" border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td align="left"><span class="TitResProd">Copyright &copy; 2012. Todos os direitos reservados. Licen&ccedil;a de uso para Norte M&aacute;quinas<br />
        Loja: Estrada do Caju&iacute; N&deg; 500, curva do Caju&iacute; &ndash; CEP: 67.145-200 -
          Ananindeua &ndash; Par&aacute;<br />
          Fone: (91) 3286-2088 / 8148-3209<br />
        </span></td>
        <td align="right"><span class="TitResProd">Desenvolvimento</span><a href="http://www.scvweb.com.br" target="_blank"><img src="img/logo_scv.png" border="0" align="absmiddle" /></a></td>
      </tr>
    </table>