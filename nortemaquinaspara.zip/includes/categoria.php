<table width="100%" border="0" cellspacing="1" cellpadding="0">
            <tr>
              <td height="25" class="TitSeta">CATEGORIAS</td>
            </tr>
            <tr>
              <td height="28" background="img/bk_lin.png"><span class="TitSeta">&raquo;</span> <span class="TitCat"><a href="view_paginas.php?titulo=Equipamentos novos" style="color:#000000">Equipamentos novos</a></span></td>
            </tr>
            <tr>
              <td height="28" background="img/bk_lin.png"><span class="TitSeta">&raquo;</span> <span class="TitCat"><a href="view_paginas.php?titulo=Equipamentos usados" style="color:#000000">Equipamentos usados</a> </span></td>
            </tr>
            <tr>
              <td height="28" background="img/bk_lin.png"><span class="TitSeta">&raquo;</span> <span class="TitCat"><a href="view_paginas.php?titulo=Produtos#FERRAMENTAS" style="color:#000000">Ferramentas</a> </span></td>
            </tr>
        </table>
