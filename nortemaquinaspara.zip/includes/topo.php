
<table width="954" height="105" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="225" align="left"><a href="index.php"><img src="img/logo_n.png" border="0" /></a></td>
        <td width="751" align="right" valign="top"><span class="TitResProd"><a href="http://webmail.nortemaquinaspara.com.br" target="_blank" >Webmail</a></span> 
          <br />
          <br />
          <table width="100%" height="58" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td   align="center" valign="middle" class="menuoff" onmouseover="className='menuon';" onmouseout="className='menuoff';"><a href="index.php" >Home</a></td>            
            <td   align="center" valign="middle" class="menuoff" onmouseover="className='menuon';" onmouseout="className='menuoff';"><a href="view_paginas.php?titulo=Empresa" >Empresa</a></td>
            <td align="center" valign="middle" class="menuoff" onmouseover="className='menuon';" onmouseout="className='menuoff';"><a href="view_paginas.php?titulo=Produtos">Produtos</a></td>
            <td align="center" valign="middle" class="menuoff" onmouseover="className='menuon';" onmouseout="className='menuoff';"><a href="view_paginas.php?titulo=Servicos">Servi&ccedil;os</a></td>
            <td align="center" valign="middle" class="menuoff" onmouseover="className='menuon';" onmouseout="className='menuoff';"><a href="view_paginas.php?titulo=Contato">Contato</a></td>
            </tr>
        </table></td>
      </tr>
    </table>