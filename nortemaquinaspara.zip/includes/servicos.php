<table width="245" border="0" cellpadding="0" cellspacing="4" background="img/bk_topcentroserv.png" style="background-repeat:no-repeat; background-position:center top;">
	<tr>
		<td height="39"><span class="TitSeta">&nbsp;Nossos SERVI&Ccedil;OS </span></td>
	</tr>
	<tr>
		<td height="212" align="left" valign="top"><span class="TitSeta"> &nbsp;&raquo;</span> <span class="TitCat"><a href="view_paginas.php?titulo=SERVICO DE REPASTILHAMENTO" style="color:#000000">Servi&ccedil;o de repastilhamento de fresas e serras circulares em widia</a></span><br />
			<span class="TitSeta">&nbsp;&raquo;</span> <span class="TitCat"><a href="view_paginas.php?titulo=SERVICO DE AFIACAO" style="color:#000000">Servi&ccedil;o de afia&ccedil;&atilde;o de facas e serras circulares em widia e a&ccedil;o hss</a></span><br />
			<span class="TitSeta">&nbsp;&raquo;</span> <span class="TitCat"><a href="view_paginas.php?titulo=SERVICO DE MANUTENCAO" style="color:#000000">Servi&ccedil;o de manuten&ccedil;&atilde;o e reforma de m&aacute;quinas ind&uacute;strias com garantia</a></span></td>
		</tr>
	</table>