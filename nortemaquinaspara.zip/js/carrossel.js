$(function(){
      $("#carrossel").jCarouselLite({
            btnPrev : '.prev',
            btnNext : '.next',
            auto    : 1000,
            speed   : 2000,
            visible : 6  //CAIO 28/03/2012
      })
})